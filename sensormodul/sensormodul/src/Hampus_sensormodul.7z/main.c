/**
 * \file
 *
 * \brief Empty user application template
 *
 */

/**
 * \mainpage User Application template doxygen documentation
 *
 * \par Empty user application template
 *
 * Bare minimum empty user application template
 *
 * \par Content
 *
 * -# Include the ASF header files (through asf.h)
 * -# Minimal main function that starts with a call to board_init()
 * -# "Insert application code here" comment
 *
 */

/*
 * Include header files for all drivers that have been imported from
 * Atmel Software Framework (ASF).
 */
#include <asf.h>
#include <util/delay.h>
#include <avr/interrupt.h> 
#include "ADC_setup.h"
#include "sensor_tabel.h"

#define NUMBER_OF_SENSORS 7

uint8_t sensor_data[NUMBER_OF_SENSORS];
uint8_t proper_sensor_data[NUMBER_OF_SENSORS];
bool sensors_to_read[NUMBER_OF_SENSORS];
bool mux_sensors = false;


enum sensor_t currentSensor = S12;
//bool sensor_switch = false;

int main (void)
{
	board_init();
	ADCsetup();
	int i = 0;
	for(i = 0; i<NUMBER_OF_SENSORS;i++);
		sensors_to_read[i] = false;
	sensors_to_read[S21] = true;
	DDRB = 0xFF; // debugging
	DDRD = 0x1F; // mux signals
	sei(); // Allow interrupts
	
	while(1)
	{
		_delay_ms(100);
		// start a conversion at the first sensor to be read
		while(!sensors_to_read[currentSensor] && currentSensor < NUMBER_OF_SENSORS)
			currentSensor++;
		if(currentSensor < NUMBER_OF_SENSORS)
		{
			switch(currentSensor)
			{
				case S11:
				PORTD = (1<<PORTD5);
				ADMUX = 0xE2;
				break;
				case S12:
				PORTD = (0<<PORTD5);
				ADMUX = 0xE2;
				break;
				case S13:
				ADMUX = 0xE5;
				case S21:
				//PORTD = (0<<PORTD5);
				ADMUX = 0xE2;
				break;
				case S22:
				ADMUX = 0xE4;
				break;
				case S23:
				PORTD = (1<<PORTD5);
				ADMUX = 0xE3;
				break;
				case S24:
				ADMUX = 0xE6;
				break;
			}
			ADCSRA |= 1<<ADSC; // Start a new conversion sweep
			if(currentSensor >= NUMBER_OF_SENSORS)
				currentSensor = S12;
			
		}
		PORTB = proper_sensor_data[S21];
		
///////////////////////////////////////////////////////////
//// These if statements determines the sensors that   ////
////			 should update its values              ////
///////////////////////////////////////////////////////////
/*		if(proper_sensor_data[S12] > 25)
			sensors_to_read[S21] = true;
		if(proper_sensor_data[S13] > 25)
			sensors_to_read[S24] == true;
		if(proper_sensor_data[S11] > 25)
		{
			sensors_to_read[S22] = true;
			sensors_to_read[S23] = true;
		}
		if(proper_sensor_data[S21] = 255)
			sensors_to_read[S21] == false;
		if(proper_sensor_data[S22] = 255)
			sensors_to_read[S22] == false;
		if(proper_sensor_data[S23] = 255)
			sensors_to_read[S23] == false;
		if(proper_sensor_data[S24] = 255)
			sensors_to_read[S24] == false;*/
///////////////////////////////////////////////////////////
	}
}


ISR(ADC_vect) // this interrupt will sweep all the sensors once and then compare data and interpolate the data from table to get the distance instead of the voltage
{
	while(!sensors_to_read[currentSensor] && currentSensor < NUMBER_OF_SENSORS)
		currentSensor++;	
	if(currentSensor < NUMBER_OF_SENSORS)
	{	
		// Will increment current_sensor as long as the current sensor is not to be read		
		switch(currentSensor)
		{
			case S11:
			PORTD = (1<<PORTD5);
			ADMUX = 0xE2;
			break;
			case S12:
			PORTD = (0<<PORTD5);
			ADMUX = 0xE2;
			break;
			case S13:
			ADMUX = 0xE5;
			case S21:
			PORTD = (0<<PORTD5);
			ADMUX = 0xE2;
			break;
			case S22:
			ADMUX = 0xE4;
			break;
			case S23:
			PORTD = (1<<PORTD5);
			ADMUX = 0xE3;
			break;
			case S24:
			ADMUX = 0xE6;
			break;
		}	
		sensor_data[currentSensor] = ADCH;
		proper_sensor_data[currentSensor] = sensorTabel(sensor_data[currentSensor],currentSensor);
		ADCSRA |= 1<<ADSC;
	}
	else
	{
		ADMUX = 0xE5;
		currentSensor = S12;
		// Ask to send proper_sensor_data over the I^2C buss
	}
}
